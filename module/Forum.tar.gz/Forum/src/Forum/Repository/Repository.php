<?php

namespace Forum\Repository;

use Doctrine\ORM\EntityRepository;

class Repository extends EntityRepository
{
 
 
}